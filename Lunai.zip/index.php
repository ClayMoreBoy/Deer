<?php
/**
 * 鹿乃 - LVLVL.CN 原创主题，整体采用兼容思想设计，自适应各种终端形式。
 * 
 * @package Lunai
 * @author 陆公子
 * @version 1.7.0
 * @link http://lvlvl.cn
 */

if (!defined('__TYPECHO_ROOT_DIR__')) exit;
$this->need('Lunai.php'); ?>


<?php $this->need('Lunaii.php'); ?>


<?php $this->need('footer.php'); ?>